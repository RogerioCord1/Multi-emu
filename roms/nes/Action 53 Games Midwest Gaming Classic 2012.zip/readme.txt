These ROMs use a pre-0.03 menu engine and have the requested censorship applied to their config files (gambling game omitted from menu, Slappin' renamed). 
4 Mbit version (includes Pogo Cats and NES15)
2 Mbit version (omits those games)